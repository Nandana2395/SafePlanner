# PCCST503 – Assignment 1: Safe Semantic Planner (Python / PyCharm)

D* Lite planner on a finite Cartesian state space with bad-state avoidance, a safety-margin
objective and incremental replanning. A* is included as a baseline / correctness oracle.

---------------------------------------------------------------------------------------
## PART 1 – Step-by-step: set up and run in PyCharm
---------------------------------------------------------------------------------------
1. **Create the project.** PyCharm → *File → New Project* → name it `safe_planner`,
   choose *Virtualenv* with Python 3.10+ → *Create*.
2. **Add the files.** Copy every file from this folder into the project root, keeping the
   `tests/` sub-folder (with its `__init__.py`).
   ```
   safe_planner/
   ├── models.py        # State, Transition, PlanningProblem, PlanningResult, Planner, score()
   ├── graph.py         # GraphModel: adjacency, bad states, safety distances, edge cost, heuristic
   ├── astar.py         # A* baseline
   ├── dstar_lite.py    # D* Lite planner + dynamic-update API
   ├── scenarios.py     # the 6 test cases from the assignment
   ├── main.py          # demo of the 6 test cases
   ├── experiments.py   # benchmark -> results.csv / results.png
   ├── tests/test_planner.py
   └── requirements.txt
   ```
3. **Install dependencies.** Open the *Terminal* tab in PyCharm: `pip install -r requirements.txt`
4. **Run the demo.** Right-click `main.py` → *Run 'main'*. Output = path, cost, safety distance,
   expanded states and time for each of the six test cases.
5. **Run the unit tests.** Right-click the `tests` folder → *Run 'Python tests in tests'*
   (or terminal: `python -m unittest discover -s tests -t .`). All 8 tests should be green.
6. **Run the experiments.** Right-click `experiments.py` → *Run*. Produces `results.csv`
   and `results.png` (use these in the report). Takes about 1 minute.
7. **Demonstration.** Screen-record steps 4–6 (PyCharm run window) and show one
   `D* Lite` update live (Test 4: remove (A,G) and replan).
8. **Report.** Copy Part 2 below into Word/LaTeX, add your name/roll number, paste the
   table from `results.csv` and the plot `results.png`.

---------------------------------------------------------------------------------------
## PART 2 – Design report
---------------------------------------------------------------------------------------
### 2.1 State representation
Each state is `State(id, embedding)` with `embedding ∈ R^d`. Internally embeddings are
stored as a NumPy matrix `(n, d)` (for vectorised distance computation) and as tuples
(for fast `math.dist` in the heuristic). A transition is
`Transition(id, src, dst, cost, safety, reliability, available)`.

### 2.2 Data structures
| Structure | Purpose | Cost |
|---|---|---|
| `succ[u]`, `pred[u]` : dict `tid → Transition` | adjacency in both directions (D* Lite needs predecessors) | O(1) add/remove edge |
| `bad_dist[u]` : dict | Euclidean distance to nearest bad state, cached | O(1) lookup |
| `g[u]`, `rhs[u]` : dict (default ∞) | D* Lite cost-to-goal estimates | O(1) |
| binary heap + `open[u]` token (lazy deletion) | priority queue with O(log n) insert/remove | O(log n) |
| `dirty` set | vertices touched by updates since last replan | O(1) |

### 2.3 Effective edge cost and safety computation
```
bad_dist(s)  = min_{b in B} || s - b ||_2                    (vectorised NumPy, chunked)
blocked(s)   = s in B  or  bad_dist(s) <= hard_margin        (never expanded => never visited)
c_eff(u,v)   = cost + w_s (1 - safety) + w_r (1 - reliability)
                    + w_p * max(0, 1 - bad_dist(v) / d_safe)
               = ∞ if the transition is unavailable or u / v is blocked
```
* Objective 1-2 (reach goal, never visit bad state): bad states are **hard constraints**
  (infinite cost) – bad states visited is zero by construction.
* Objective 3-4 (cost vs. safety margin): the proximity term is a *soft* penalty that rises
  linearly from 0 (distance ≥ `d_safe`) to `w_p` (distance 0). Minimising `Σ c_eff`
  therefore trades extra path cost against clearance. `w_p = 0` gives the cost-only path
  (Test 3b), `w_p = 5` gives the safer, longer path (Test 3a). `hard_margin > 0` turns the
  margin into a hard constraint.
* Reported `safety_score` = min over visited states of `bad_dist`. `score()` in `models.py`
  implements `Score(P) = αG − βC + γD + δR`.

### 2.4 Heuristic
`h(a,b) = κ · ||a − b||₂`, with `κ = min over transitions of cost / Euclidean length`.
Because `c_eff ≥ cost ≥ κ·length` for every edge, `h` is **admissible and consistent**, so
both A* and D* Lite return optimal paths. If an added transition lowers `κ`, the search is
reset (rare; handled automatically in `add_transition`).

### 2.5 Algorithm – D* Lite
Search runs backwards from the goal (`g` = cost-to-goal) so that when the agent's start
moves (`move_start`, with the `km` offset) or edges change, only inconsistent vertices are
repaired. Each update marks the affected vertices dirty; `replan()` calls `update_vertex`
on them and resumes `compute_shortest_path`.

| Change | Handled by | What is reused |
|---|---|---|
| transition unavailable / removed | `set_transition_available`, `remove_transition` → dirty = {src} | all g/rhs values |
| new transition | `add_transition` → dirty = {src} | all g/rhs (reset only if κ decreases) |
| bad states change | `set_bad_states` → recompute `bad_dist` (vectorised), dirty = changed vertices + their predecessors | graph, g/rhs |
| agent moves | `move_start` → `km += h(s_last, s_new)` | all g/rhs |
| goal changes | `set_goal` → reset g/rhs/queue only | graph, adjacency, `bad_dist` table, edge costs, heuristic scale (no data structure is rebuilt) |

(Goal change cannot reuse g/rhs because D* Lite's values are costs *to the goal*.)

### 2.6 Complexity (V states, E transitions, k bad states, d dimensions)
* Build graph: O(V + E); safety table: O(V·k·d) brute force (O(V log k) with a KD-tree).
* One full search: O(E log V) time (binary heap).
* Replanning after a local change: O(m log V) where m = vertices whose g/rhs become inconsistent
  (typically ≪ V); worst case equal to a full search.
* Bad-state update: O(V·k·d) for the table, then O(changed) heap work.
* Space: O(V·d + E) for the model + O(V) for g, rhs, `bad_dist`, + O(E) worst-case heap (lazy deletion).

### 2.7 Experimental results (`python experiments.py`, random geometric graphs, 8-NN, 5 % bad states)
12 dynamic events per graph (block 3 transitions on the current path, add 3 new bad states, add shortcut, change goal).
Mean over events (my machine – re-run to get yours):

| n states | D* Lite expanded | A* from scratch expanded | D* ms | A* ms |
|---|---|---|---|---|
| 500  | 60  | 110  | 5.5  | 1.1  |
| 2000 | 281 | 539  | 26.9 | 6.1  |
| 5000 | 500 | 1213 | 62.5 | 19.1 |

Per event type (n = 5000, expanded D*/A*): blocked transitions 634/1803, new bad states 424/1972,
shortcut 198/430, goal change 746/648.

Other measured values: success rate 100 %, **bad states visited = 0** in every run, D* path cost equals
A* path cost on every replan (verified), peak memory of initial planning 1.3 / 5.4 / 14.7 MB for
n = 500 / 2000 / 5000, minimum distance to bad states 0.7–5.5 units along replans.

**Discussion (be honest in your report):** D* Lite expands 2–4× fewer states than A* for
edge/bad-state changes and finds an identical optimal path, but in pure Python its per-expansion
overhead (heap + rhs maintenance) is higher, so wall-clock replanning is *not* faster here;
A* with a good heuristic is a strong baseline on graphs of this size. The advantage of D* Lite grows
with graph size, with a moving start (`move_start`), and in compiled languages. Goal changes give
no advantage (search is restarted) – this is inherent to backward D* Lite.

---------------------------------------------------------------------------------------
## PART 3 – User manual
---------------------------------------------------------------------------------------
```python
from dstar_lite import DStarLitePlanner
from graph import Weights
from models import PlanningProblem, State, Transition

problem = PlanningProblem(
    initial_state=0, goal_state=3, bad_states=[2],
    states=[State(0,[0,0]), State(1,[1,1]), State(2,[2,1]), State(3,[3,0]), State(4,[1.5,-1])],
    transitions=[Transition(0,0,1,1.0), Transition(1,1,2,1.0), Transition(2,2,3,1.0),
                 Transition(3,0,4,2.0, safety=0.9, reliability=0.95), Transition(4,4,3,2.0)])

planner = DStarLitePlanner(Weights(w_proximity=5.0, d_safe=2.0))   # tune safety/cost trade-off
result  = planner.plan(problem)            # PlanningResult
print(result.success, result.state_path, result.total_cost, result.safety_score)

# --- dynamic environment: update, then call replan() ---
planner.set_transition_available(4, False)          # transition becomes unavailable
planner.add_transition(Transition(10, 0, 3, 3.5))   # new transition
planner.remove_transition(10)                       # remove transition
planner.set_bad_states([2, 4])                      # new set of bad states
planner.set_goal(1)                                 # new goal
planner.move_start(4)                               # agent advanced along the path
result = planner.replan()
```
`PlanningResult` fields: `success, state_path, transition_path, total_cost, effective_cost,
safety_score (min distance to bad), total_reliability, bad_states_visited, expanded, planning_time, message`.

Weights: `w_safety`, `w_reliability`, `w_proximity`, `d_safe`, `hard_margin`.
Limitations: non-negative costs only; the set of states is fixed after `plan()` (transitions may change).

---------------------------------------------------------------------------------------
## PART 4 – Optional bonus ideas (not implemented)
---------------------------------------------------------------------------------------
Multi-goal planning (run D* Lite per goal and keep the cheapest), time-dependent availability
(attach `[t_start, t_end]` to each transition and call `set_transition_available` when the clock
ticks), KD-tree (`scipy.spatial.cKDTree`) for the safety table, knowledge-graph test (use node
embeddings as `State.embedding`).
